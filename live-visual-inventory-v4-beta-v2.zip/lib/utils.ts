import { InventoryItem, InventoryStats } from './types';

const DEFAULT_SHEET_ID = '10VF9Yk-r9pINttngYz8MNXFk-ujPAvvOukF7Ypf4LBg';

// Helper to extract ID from URL
export const extractSheetId = (input: string): string => {
  if (!input) return DEFAULT_SHEET_ID;
  const match = input.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return match ? match[1] : (input.includes('/') ? DEFAULT_SHEET_ID : input);
};

// Helper: Convert Column Letter (A, B, AA) to 0-based index
export const getColumnIndex = (letter: string | undefined): number => {
  if (!letter) return -1;
  const clean = letter.replace(/[^A-Za-z]/g, '').toUpperCase();
  if (!clean) return -1;
  
  let index = 0;
  for (let i = 0; i < clean.length; i++) {
    index = index * 26 + (clean.charCodeAt(i) - 64);
  }
  return index - 1;
};

export const calculateStats = (items: InventoryItem[]): InventoryStats => {
  const categories: Record<string, number> = {};
  items.forEach(item => {
    const cat = item.category || 'Uncategorized';
    categories[cat] = (categories[cat] || 0) + 1;
  });

  return {
    totalItems: items.length,
    totalValue: items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
    lowStockCount: items.filter(i => i.status === 'Low Stock').length,
    outOfStockCount: items.filter(i => i.status === 'Out of Stock').length,
    categories
  };
};