import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { InventoryItem, InventoryStats, ColumnMapping, SortField, SortOrder } from '../lib/types';
import { fetchInventory, calculateStats } from '../services/inventoryService';

interface UseInventoryProps {
  sheetUrl: string;
  mapping: Partial<ColumnMapping>;
  hiddenIds: string[];
  imageOverrides: Record<string, string>;
  searchQuery: string;
  multiIds: string[];
  quickFilter: 'ALL' | 'LOW' | 'OUT';
  selectedModel: string | null;
  sortField: SortField | null;
  sortOrder: SortOrder;
  viewMode: 'grid' | 'list' | 'sheet';
}

export const useInventory = ({
  sheetUrl,
  mapping,
  hiddenIds,
  imageOverrides,
  searchQuery,
  multiIds,
  quickFilter,
  selectedModel,
  sortField,
  sortOrder,
  viewMode
}: UseInventoryProps) => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [visibleCount, setVisibleCount] = useState(60);
  
  const loaderRef = useRef<HTMLDivElement>(null);

  const loadData = async (isBackground = false) => {
    if (isBackground) setSyncing(true);
    else setLoading(true);
    
    try {
      const data = await fetchInventory(sheetUrl, mapping);
      setItems(data);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      console.error(err);
      if (!isBackground) setError("Unable to load inventory data. Please check the sheet settings and ensure the URL is correct.");
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(() => loadData(true), 30000);
    return () => clearInterval(interval);
  }, [sheetUrl]); // Dependencies for refetch

  // Apply Overrides
  const accessibleItems = useMemo(() => {
    return items.map(item => ({
      ...item,
      imageUrl: imageOverrides[item.id] || item.imageUrl
    })).filter(item => !hiddenIds.includes(item.id));
  }, [items, hiddenIds, imageOverrides]);

  // Derived Stats & Models
  const uniqueModels = useMemo(() => {
    const models = new Set(accessibleItems.map(i => i.category).filter(c => c && c !== 'Uncategorized'));
    return Array.from(models).sort();
  }, [accessibleItems]);

  const stats = useMemo(() => calculateStats(accessibleItems), [accessibleItems]);

  // Filtering & Sorting
  const filteredItems = useMemo(() => {
    let result = accessibleItems;
    
    const hasMultiSearch = multiIds.length > 0;
    const hasQuerySearch = searchQuery.trim().length > 0;
    const isSearchActive = hasMultiSearch || hasQuerySearch;

    if (isSearchActive) {
      if (hasMultiSearch) {
        result = result.filter(item => 
          multiIds.some(term => {
            const lowerTerm = term.toLowerCase();
            return (
              item.id.toLowerCase().includes(lowerTerm) ||
              item.sku?.toLowerCase().includes(lowerTerm) ||
              item.partNumber?.toLowerCase().includes(lowerTerm) ||
              item.name.toLowerCase().includes(lowerTerm) ||
              item.category.toLowerCase().includes(lowerTerm)
            );
          })
        );
      } 
      else if (hasQuerySearch) {
        const lowerQ = searchQuery.toLowerCase();
        result = result.filter(item => 
          item.id.toLowerCase().includes(lowerQ) ||
          item.sku?.toLowerCase().includes(lowerQ) ||
          item.partNumber?.toLowerCase().includes(lowerQ) ||
          item.name.toLowerCase().includes(lowerQ) ||
          item.category.toLowerCase().includes(lowerQ)
        );
      }
    } else {
      if (quickFilter === 'LOW') {
        result = result.filter(item => item.status === 'Low Stock');
      } else if (quickFilter === 'OUT') {
        result = result.filter(item => item.status === 'Out of Stock');
      }

      if (selectedModel) {
        result = result.filter(item => item.category === selectedModel);
      }
    }

    // Sort logic - Skip sorting in Sheet Mode to preserve original sheet order
    if (sortField && viewMode !== 'sheet') {
      result = [...result].sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];

        if (typeof valA === 'string') valA = valA.toLowerCase();
        if (typeof valB === 'string') valB = valB.toLowerCase();

        if (valA === undefined) return 1;
        if (valB === undefined) return -1;

        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [accessibleItems, searchQuery, multiIds, sortField, sortOrder, quickFilter, selectedModel, viewMode]);

  // Pagination / Virtualization
  useEffect(() => {
    setVisibleCount(60);
  }, [searchQuery, multiIds, quickFilter, selectedModel, sortField, sortOrder, viewMode]);

  const displayedItems = useMemo(() => {
    if (viewMode === 'sheet') return filteredItems;
    return filteredItems.slice(0, visibleCount);
  }, [filteredItems, visibleCount, viewMode]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setVisibleCount((prev) => prev + 60);
        }
      },
      { root: null, rootMargin: '500px', threshold: 0.1 }
    );
    if (loaderRef.current) observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [filteredItems, viewMode]);

  const refresh = useCallback(() => loadData(true), [sheetUrl]);

  return {
    items: accessibleItems,
    filteredItems,
    displayedItems,
    stats,
    uniqueModels,
    loading,
    syncing,
    error,
    lastUpdated,
    refresh,
    loaderRef,
    visibleCount
  };
};