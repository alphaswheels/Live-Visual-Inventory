import React, { useEffect } from 'react';
import { InventoryStats } from '../lib/types';

interface SEOProps {
  title?: string;
  description?: string;
  stats?: InventoryStats;
}

const SEO: React.FC<SEOProps> = ({ title, description, stats }) => {
  useEffect(() => {
    const baseTitle = "Live Visual Inventory";
    const newTitle = title ? `${title} | ${baseTitle}` : baseTitle;
    document.title = newTitle;

    // Update meta description
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && description) {
      metaDesc.setAttribute("content", description);
    } else if (metaDesc && stats) {
       metaDesc.setAttribute("content", `Real-time inventory tracking: ${stats.totalItems} items managed. ${stats.lowStockCount} low stock alerts.`);
    }
  }, [title, description, stats]);

  return null;
};

export default SEO;